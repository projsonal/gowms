package constant

// Supplier
const ()
